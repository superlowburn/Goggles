"use strict";
(() => {
  // src/shared/site-policy.ts
  var socialMigrationPromises = /* @__PURE__ */ new WeakMap();
  var protectedMode = "protected";
  var trustedMode = "trusted";
  var redditPseudoCommunities = /* @__PURE__ */ new Set(["all", "popular", "mod", "friends"]);
  var defaultPolicyKey = "default-site-mode";
  var socialPlatforms = [
    { id: "facebook", hosts: ["facebook.com"] },
    { id: "instagram", hosts: ["instagram.com"] },
    { id: "reddit", hosts: ["reddit.com"] },
    { id: "x", hosts: ["x.com", "twitter.com"] },
    { id: "tiktok", hosts: ["tiktok.com"] },
    { id: "threads", hosts: ["threads.com", "threads.net"] },
    { id: "bluesky", hosts: ["bsky.app"] },
    { id: "youtube", hosts: ["youtube.com"] }
  ];
  function policyKey(origin) {
    return `site-policy:${origin}`;
  }
  function socialPolicyKey(platform) {
    return `social-policy:${platform}`;
  }
  function subredditPolicyKey(name) {
    return `reddit-subreddit-policy:${name.toLowerCase()}`;
  }
  function subredditDisplayKey(name) {
    return `reddit-subreddit-display:${name.toLowerCase()}`;
  }
  function descriptionsKey(origin) {
    return `site-descriptions:${origin}`;
  }
  function isSiteMode(value) {
    return value === "trusted" || value === "protected" || value === "strict";
  }
  function normalizeOrigin(value) {
    try {
      const url = new URL(value);
      return url.protocol === "http:" || url.protocol === "https:" ? url.origin : null;
    } catch {
      return null;
    }
  }
  function socialPlatformForOrigin(origin) {
    const normalizedOrigin = normalizeOrigin(origin);
    if (!normalizedOrigin) return null;
    const hostname = new URL(normalizedOrigin).hostname;
    return socialPlatforms.find(
      ({ hosts }) => hosts.some((host) => hostname === host || hostname.endsWith(`.${host}`))
    ) ?? null;
  }
  function parseRedditCommunity(value) {
    try {
      const url = new URL(value);
      if (socialPlatformForOrigin(url.origin)?.id !== "reddit") return null;
      const segments = url.pathname.split("/");
      const displayName = segments[1] === "r" ? segments[2] : void 0;
      if (!displayName || !/^[A-Za-z0-9_]{3,21}$/.test(displayName)) return null;
      const canonicalName = displayName.toLowerCase();
      if (redditPseudoCommunities.has(canonicalName)) return null;
      return { displayName, canonicalName };
    } catch {
      return null;
    }
  }
  function defaultPolicyForOrigin(origin) {
    const normalizedOrigin = normalizeOrigin(origin);
    if (!normalizedOrigin) return protectedMode;
    return socialPlatformForOrigin(normalizedOrigin) ? protectedMode : trustedMode;
  }
  function supportedMode(value) {
    if (value === "strict") return "protected";
    return value === "trusted" || value === "protected" ? value : null;
  }
  function supportedSubredditMode(value) {
    return value === "trusted" || value === "protected" ? value : null;
  }
  function canonicalSubredditName(value) {
    return /^[A-Za-z0-9_]{3,21}$/.test(value) ? value.toLowerCase() : null;
  }
  function isCanonicalSubredditName(value) {
    return typeof value === "string" && /^[a-z0-9_]{3,21}$/.test(value);
  }
  function isSubredditDisplayNameForCanonical(value, canonicalName) {
    return typeof value === "string" && canonicalSubredditName(value) === canonicalName;
  }
  var SitePolicyStore = class {
    constructor(area, onChanged) {
      this.area = area;
      this.onChanged = onChanged;
    }
    area;
    onChanged;
    async get(origin) {
      return (await this.resolve(origin)).mode;
    }
    async resolve(value) {
      const normalizedOrigin = normalizeOrigin(value);
      if (!normalizedOrigin) return { mode: defaultPolicyForOrigin(value) };
      const exactKey = policyKey(normalizedOrigin);
      const platform = socialPlatformForOrigin(normalizedOrigin);
      if (!platform) {
        return { mode: supportedMode((await this.area.get(exactKey))[exactKey]) ?? trustedMode };
      }
      const platformKey = socialPolicyKey(platform.id);
      const community = parseRedditCommunity(value);
      const subredditKey = community ? subredditPolicyKey(community.canonicalName) : null;
      const values = await this.area.get([
        ...subredditKey ? [subredditKey] : [],
        platformKey,
        exactKey
      ]);
      const inherited = platformKey in values ? supportedMode(values[platformKey]) ?? protectedMode : supportedMode(values[exactKey]) ?? protectedMode;
      const inheritedMode = inherited === "trusted" ? "trusted" : "protected";
      if (!community || !subredditKey) return { mode: inheritedMode };
      const override = supportedSubredditMode(values[subredditKey]);
      return {
        mode: override ?? inheritedMode,
        reddit: {
          ...community,
          inheritedMode,
          hasOverride: override !== null
        }
      };
    }
    async set(origin, mode) {
      const normalizedOrigin = normalizeOrigin(origin);
      if (!normalizedOrigin) return;
      const platform = socialPlatformForOrigin(normalizedOrigin);
      const key = platform ? socialPolicyKey(platform.id) : policyKey(normalizedOrigin);
      await this.area.set({ [key]: supportedMode(mode) ?? protectedMode });
    }
    async setDefault(mode) {
      await this.area.set({ [defaultPolicyKey]: supportedMode(mode) ?? protectedMode });
    }
    async setSubreddit(name, mode, displayName) {
      const canonicalName = canonicalSubredditName(name);
      if (!canonicalName) return;
      await this.area.set({
        [subredditPolicyKey(canonicalName)]: mode,
        ...isSubredditDisplayNameForCanonical(displayName, canonicalName) ? { [subredditDisplayKey(canonicalName)]: displayName } : {}
      });
    }
    async resetSubreddit(name) {
      const canonicalName = canonicalSubredditName(name);
      if (!canonicalName) return;
      await this.area.remove?.([
        subredditPolicyKey(canonicalName),
        subredditDisplayKey(canonicalName)
      ]);
    }
    async getDescriptionsVisible(origin) {
      const key = descriptionsKey(origin);
      return (await this.area.get(key))[key] === true;
    }
    async setDescriptionsVisible(origin, visible) {
      await this.area.set({ [descriptionsKey(origin)]: visible });
    }
    watch(origin, listener) {
      const normalizedOrigin = normalizeOrigin(origin);
      if (!normalizedOrigin) return () => {
      };
      const exactKey = policyKey(normalizedOrigin);
      const platform = socialPlatformForOrigin(normalizedOrigin);
      const community = parseRedditCommunity(origin);
      const keys = platform ? [
        ...community ? [subredditPolicyKey(community.canonicalName)] : [],
        socialPolicyKey(platform.id),
        exactKey
      ] : [exactKey];
      const onChange = (changes, areaName) => {
        if (areaName !== "local" || !keys.some((key) => key in changes)) return;
        void this.get(origin).then(listener);
      };
      this.onChanged?.addListener(onChange);
      return () => this.onChanged?.removeListener(onChange);
    }
  };
  async function migrateSocialPolicies(area) {
    const values = await area.get(null) ?? {};
    const updates = {};
    for (const platform of socialPlatforms) {
      const platformKey = socialPolicyKey(platform.id);
      if (platformKey in values) continue;
      const hasTrustedLegacyRule = Object.entries(values).some(([key, value]) => {
        if (!key.startsWith("site-policy:") || supportedMode(value) !== trustedMode) return false;
        const origin = key.slice("site-policy:".length);
        return normalizeOrigin(origin) === origin && socialPlatformForOrigin(origin)?.id === platform.id;
      });
      if (hasTrustedLegacyRule) updates[platformKey] = trustedMode;
    }
    if (Object.keys(updates).length > 0) await area.set(updates);
  }
  function prepareSocialPolicies(area) {
    let migration = socialMigrationPromises.get(area);
    if (!migration) {
      migration = migrateSocialPolicies(area).catch(() => {
        socialMigrationPromises.delete(area);
      });
      socialMigrationPromises.set(area, migration);
    }
    return migration;
  }

  // src/shared/blocked-subjects.ts
  var blockedSubjectsKey = "blocked-subjects";
  var defaultTrumpKeywords = [
    "Donald Trump",
    "Donald J. Trump",
    "President Trump",
    "Former President Trump",
    "Trump",
    "@realDonaldTrump",
    "The Donald"
  ];
  function parseBlockedSubjects(value) {
    if (!value || typeof value !== "object") {
      return { subjects: defaultSubjects() };
    }
    const candidate = value;
    if (Array.isArray(candidate.subjects)) {
      const subjects = candidate.subjects.flatMap((subject) => {
        if (!subject || typeof subject !== "object") return [];
        const item = subject;
        const name = typeof item.name === "string" ? normalizeName(item.name) : "";
        const keywords2 = Array.isArray(item.keywords) ? uniqueKeywords(item.keywords.filter((keyword) => typeof keyword === "string")) : [];
        return name && keywords2.length > 0 ? [{ name, enabled: item.enabled === true, keywords: keywords2 }] : [];
      });
      return { subjects };
    }
    const keywords = Array.isArray(candidate.keywords) ? uniqueKeywords(candidate.keywords.filter((item) => typeof item === "string")) : [];
    return {
      subjects: [{
        name: "Donald Trump",
        enabled: candidate.enabled === true,
        keywords: keywords.length > 0 ? keywords : [...defaultTrumpKeywords]
      }]
    };
  }
  var BlockedSubjectsStore = class {
    constructor(area, onChanged) {
      this.area = area;
      this.onChanged = onChanged;
    }
    area;
    onChanged;
    async get() {
      return parseBlockedSubjects((await this.area.get(blockedSubjectsKey))[blockedSubjectsKey]);
    }
    async set(config) {
      await this.area.set({ [blockedSubjectsKey]: parseBlockedSubjects(config) });
    }
    watch(listener) {
      const onChange = (changes, area) => {
        if (area === "local" && blockedSubjectsKey in changes) {
          listener(parseBlockedSubjects(changes[blockedSubjectsKey]?.newValue));
        }
      };
      this.onChanged?.addListener(onChange);
      return () => this.onChanged?.removeListener(onChange);
    }
  };
  function uniqueKeywords(keywords) {
    const seen = /* @__PURE__ */ new Set();
    return keywords.flatMap((keyword) => {
      const normalized = keyword.replace(/\s+/gu, " ").trim();
      const key = normalized.toLocaleLowerCase();
      if (!normalized || seen.has(key)) return [];
      seen.add(key);
      return [normalized];
    });
  }
  function normalizeName(name) {
    return name.replace(/\s+/gu, " ").trim();
  }
  function defaultSubjects() {
    return [{ name: "Donald Trump", enabled: false, keywords: [...defaultTrumpKeywords] }];
  }

  // src/background/service-worker.ts
  function isSocialPlatformId(value) {
    return typeof value === "string" && socialPlatforms.some(({ id }) => id === value);
  }
  function isTabId(value) {
    return typeof value === "number" && Number.isInteger(value) && value >= 0;
  }
  function isOptionsSender(sender, extensionId) {
    if (sender.id !== extensionId || !sender.url) return false;
    try {
      const url = new URL(sender.url);
      return url.protocol === "chrome-extension:" && url.hostname === extensionId && (url.pathname === "/options/options.html" || url.pathname === "/dist/options/options.html");
    } catch {
      return false;
    }
  }
  function isExtensionMessage(message) {
    if (!message || typeof message !== "object" || !("type" in message)) return false;
    switch (message.type) {
      case "policy:get-current":
      case "policy:get-social":
      case "policy:list-subreddits":
        return true;
      case "options:open":
        return true;
      case "policy:get-tab":
        return "tabId" in message && isTabId(message.tabId);
      case "policy:set-tab":
        return "tabId" in message && isTabId(message.tabId) && "mode" in message && isSiteMode(message.mode) && "expectedOrigin" in message && typeof message.expectedOrigin === "string";
      case "policy:set-social":
        return "platform" in message && isSocialPlatformId(message.platform) && "mode" in message && (message.mode === "protected" || message.mode === "trusted");
      case "policy:set-subreddit":
        return "tabId" in message && isTabId(message.tabId) && "expectedSubreddit" in message && isCanonicalSubredditName(message.expectedSubreddit) && "mode" in message && (message.mode === "protected" || message.mode === "trusted");
      case "policy:reset-subreddit":
        return "tabId" in message && isTabId(message.tabId) && "expectedSubreddit" in message && isCanonicalSubredditName(message.expectedSubreddit);
      case "policy:reset-subreddit-setting":
        return "canonicalName" in message && isCanonicalSubredditName(message.canonicalName);
      default:
        return false;
    }
  }
  function originFor(tab) {
    return tab?.url ? normalizeOrigin(tab.url) ?? void 0 : void 0;
  }
  async function contextFor(tab, store, blockedSubjectsStore) {
    const origin = originFor(tab);
    if (!origin) return { error: "unsupported-page" };
    const policy = await store.resolve(tab?.url ?? origin);
    return {
      origin,
      ...policy,
      blockedSubjects: await blockedSubjectsStore.get()
    };
  }
  async function handleExtensionMessage(message, sender, deps) {
    if (!isExtensionMessage(message)) return { error: "invalid-message" };
    if ((message.type === "policy:get-social" || message.type === "policy:set-social" || message.type === "policy:list-subreddits" || message.type === "policy:reset-subreddit-setting") && !isOptionsSender(sender, deps.extensionId ?? chrome.runtime.id)) {
      return { error: "invalid-message" };
    }
    await (deps.policyReady ?? prepareSocialPolicies(deps.storage));
    const store = new SitePolicyStore(deps.storage);
    const blockedSubjectsStore = new BlockedSubjectsStore(deps.storage);
    switch (message.type) {
      case "options:open":
        await (deps.openOptionsPage ?? (() => chrome.runtime.openOptionsPage()))();
        return { opened: true };
      case "policy:get-current":
        return contextFor(sender.tab, store, blockedSubjectsStore);
      case "policy:get-social": {
        const keys = socialPlatforms.map(({ id }) => socialPolicyKey(id));
        const values = await deps.storage.get(keys);
        return {
          socialPolicies: Object.fromEntries(socialPlatforms.map(({ id }) => [
            id,
            values[socialPolicyKey(id)] === "trusted" ? "trusted" : "protected"
          ]))
        };
      }
      case "policy:set-social":
        await deps.storage.set({ [socialPolicyKey(message.platform)]: message.mode });
        return { platform: message.platform, mode: message.mode };
      case "policy:list-subreddits": {
        const prefix = subredditPolicyKey("");
        const values = await deps.storage.get(null);
        const subredditPolicies = Object.entries(values).flatMap(([
          key,
          value
        ]) => {
          const canonicalName = key.startsWith(prefix) ? key.slice(prefix.length) : "";
          const displayName = values[subredditDisplayKey(canonicalName)];
          return isCanonicalSubredditName(canonicalName) && (value === "protected" || value === "trusted") ? [{
            canonicalName,
            displayName: isSubredditDisplayNameForCanonical(displayName, canonicalName) ? displayName : canonicalName,
            mode: value
          }] : [];
        }).sort((first, second) => first.canonicalName.localeCompare(second.canonicalName));
        return { subredditPolicies };
      }
      case "policy:reset-subreddit-setting":
        await deps.storage.remove?.([
          subredditPolicyKey(message.canonicalName),
          subredditDisplayKey(message.canonicalName)
        ]);
        return { canonicalName: message.canonicalName, removed: true };
      case "policy:get-tab":
        return contextFor(await deps.tabs.get(message.tabId), store, blockedSubjectsStore);
      case "policy:set-tab": {
        const origin = originFor(await deps.tabs.get(message.tabId));
        if (!origin) return { error: "unsupported-page" };
        if (origin !== message.expectedOrigin) return { error: "origin-changed" };
        await store.set(origin, message.mode);
        return { origin, mode: message.mode === "strict" ? "protected" : message.mode };
      }
      case "policy:set-subreddit":
      case "policy:reset-subreddit": {
        const tab = await deps.tabs.get(message.tabId);
        const community = tab.url ? parseRedditCommunity(tab.url) : null;
        if (community?.canonicalName !== message.expectedSubreddit) {
          return { error: "subreddit-changed" };
        }
        if (message.type === "policy:set-subreddit") {
          await store.setSubreddit(community.canonicalName, message.mode, community.displayName);
        } else {
          await store.resetSubreddit(community.canonicalName);
        }
        return contextFor(tab, store, blockedSubjectsStore);
      }
    }
  }
  function installFirstRun(runtime, storage) {
    runtime.onInstalled.addListener(({ reason }) => {
      if (storage) void prepareSocialPolicies(storage);
      if (reason === "install") void runtime.openOptionsPage();
    });
  }
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    void handleExtensionMessage(message, sender, {
      storage: chrome.storage.local,
      tabs: chrome.tabs,
      openOptionsPage: () => chrome.runtime.openOptionsPage(),
      policyReady: productionPolicyReady,
      extensionId: chrome.runtime.id
    }).then(sendResponse);
    return true;
  });
  var productionPolicyReady = prepareSocialPolicies(chrome.storage.local);
  if (chrome.runtime.onInstalled) installFirstRun(chrome.runtime, chrome.storage.local);
})();
//# sourceMappingURL=service-worker.js.map
