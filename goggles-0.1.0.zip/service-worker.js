"use strict";
(() => {
  // src/shared/site-policy.ts
  var defaultMode = "protected";
  var defaultPolicyKey = "default-site-mode";
  function policyKey(origin) {
    return `site-policy:${origin}`;
  }
  function descriptionsKey(origin) {
    return `site-descriptions:${origin}`;
  }
  function isSiteMode(value) {
    return value === "trusted" || value === "protected" || value === "strict";
  }
  function supportedMode(value) {
    if (value === "strict") return "protected";
    return value === "trusted" || value === "protected" ? value : null;
  }
  var SitePolicyStore = class {
    constructor(area, onChanged) {
      this.area = area;
      this.onChanged = onChanged;
    }
    area;
    onChanged;
    async get(origin) {
      const key = policyKey(origin);
      const values = await this.area.get([key, defaultPolicyKey]);
      const value = values[key];
      return supportedMode(value) ?? supportedMode(values[defaultPolicyKey]) ?? defaultMode;
    }
    async set(origin, mode) {
      await this.area.set({ [policyKey(origin)]: supportedMode(mode) ?? defaultMode });
    }
    async setDefault(mode) {
      await this.area.set({ [defaultPolicyKey]: supportedMode(mode) ?? defaultMode });
    }
    async getDescriptionsVisible(origin) {
      const key = descriptionsKey(origin);
      return (await this.area.get(key))[key] === true;
    }
    async setDescriptionsVisible(origin, visible) {
      await this.area.set({ [descriptionsKey(origin)]: visible });
    }
    watch(origin, listener) {
      const key = policyKey(origin);
      const onChange = (changes, areaName) => {
        if (areaName !== "local" || !(key in changes)) return;
        listener(supportedMode(changes[key]?.newValue) ?? defaultMode);
      };
      this.onChanged?.addListener(onChange);
      return () => this.onChanged?.removeListener(onChange);
    }
  };

  // src/shared/blocked-subjects.ts
  var blockedSubjectsKey = "blocked-subjects";
  var defaultTrumpKeywords = [
    "Donald Trump",
    "Donald J. Trump",
    "President Trump",
    "Former President Trump",
    "Trump",
    "@realDonaldTrump",
    "The Donald"
  ];
  function parseBlockedSubjects(value) {
    if (!value || typeof value !== "object") {
      return { enabled: false, keywords: [...defaultTrumpKeywords] };
    }
    const candidate = value;
    const keywords = Array.isArray(candidate.keywords) ? uniqueKeywords(candidate.keywords.filter((item) => typeof item === "string")) : [];
    return {
      enabled: candidate.enabled === true,
      keywords: keywords.length > 0 ? keywords : [...defaultTrumpKeywords]
    };
  }
  var BlockedSubjectsStore = class {
    constructor(area, onChanged) {
      this.area = area;
      this.onChanged = onChanged;
    }
    area;
    onChanged;
    async get() {
      return parseBlockedSubjects((await this.area.get(blockedSubjectsKey))[blockedSubjectsKey]);
    }
    async set(config) {
      await this.area.set({ [blockedSubjectsKey]: parseBlockedSubjects(config) });
    }
    watch(listener) {
      const onChange = (changes, area) => {
        if (area === "local" && blockedSubjectsKey in changes) {
          listener(parseBlockedSubjects(changes[blockedSubjectsKey]?.newValue));
        }
      };
      this.onChanged?.addListener(onChange);
      return () => this.onChanged?.removeListener(onChange);
    }
  };
  function uniqueKeywords(keywords) {
    const seen = /* @__PURE__ */ new Set();
    return keywords.flatMap((keyword) => {
      const normalized = keyword.replace(/\s+/gu, " ").trim();
      const key = normalized.toLocaleLowerCase();
      if (!normalized || seen.has(key)) return [];
      seen.add(key);
      return [normalized];
    });
  }

  // src/media/provider-frames.ts
  var supportedProviders = [
    { host: "www.youtube.com", path: /^\/embed\/[^/]+$/ },
    { host: "www.youtube-nocookie.com", path: /^\/embed\/[^/]+$/ },
    { host: "player.vimeo.com", path: /^\/video\/[^/]+$/ }
  ];
  function supportedProviderUrl(source, base = "https://invalid.local/") {
    try {
      const url = new URL(source, base);
      return url.protocol === "https:" && supportedProviders.some(
        ({ host, path }) => url.hostname === host && path.test(url.pathname)
      ) ? url : null;
    } catch {
      return null;
    }
  }

  // src/background/provider-request-gate.ts
  var grantLifetimeMs = 1e4;
  var ProviderRequestGate = class {
    updateSessionRules;
    getSessionRules;
    token;
    ruleId;
    setTimer;
    clearTimer;
    grants = /* @__PURE__ */ new Map();
    operations = Promise.resolve();
    constructor(environment) {
      this.updateSessionRules = environment.updateSessionRules;
      this.getSessionRules = environment.getSessionRules;
      this.token = environment.token ?? randomToken;
      this.ruleId = environment.ruleId ?? randomRuleId;
      this.setTimer = environment.setTimeout ?? ((callback, delay) => self.setTimeout(callback, delay));
      this.clearTimer = environment.clearTimeout ?? ((handle) => self.clearTimeout(handle));
    }
    async authorize(tabId, source, disableAutoplay = true) {
      return this.serialize(() => this.authorizeNow(
        tabId,
        source,
        disableAutoplay
      ));
    }
    async revoke(tabId, grantId) {
      await this.serialize(() => this.revokeNow(tabId, grantId));
    }
    async revokeTab(tabId) {
      await this.serialize(() => this.revokeTabNow(tabId));
    }
    async sweep() {
      await this.serialize(() => this.sweepNow());
    }
    async authorizeNow(tabId, source, disableAutoplay) {
      const parsed = supportedProviderUrl(source);
      if (!parsed) throw new TypeError("Unsupported provider URL");
      if (disableAutoplay) parsed.searchParams.set("autoplay", "0");
      parsed.searchParams.set("eg_eclipse_goggles", this.token());
      const grantId = this.uniqueRuleId();
      const requestUrl = new URL(parsed.href);
      requestUrl.hash = "";
      const rule = {
        id: grantId,
        priority: 2,
        action: { type: "allow" },
        condition: {
          regexFilter: `^${escapeRegex(requestUrl.href)}$`,
          resourceTypes: ["sub_frame"],
          tabIds: [tabId]
        }
      };
      await this.updateSessionRules({ addRules: [rule], removeRuleIds: [] });
      const timer = this.setTimer(() => void this.revoke(tabId, grantId), grantLifetimeMs);
      this.grants.set(grantId, {
        tabId,
        timer
      });
      return { grantId, source: parsed.href };
    }
    async revokeNow(tabId, grantId) {
      const local = this.grants.get(grantId);
      let ownerTabId = local?.tabId;
      if (ownerTabId === void 0 && this.getSessionRules) {
        const [rule] = await this.getSessionRules({ ruleIds: [grantId] });
        if (rule?.condition.tabIds?.includes(tabId)) ownerTabId = tabId;
      }
      if (ownerTabId !== tabId) return;
      await this.updateSessionRules({ addRules: [], removeRuleIds: [grantId] });
      if (local) this.clearTimer(local.timer);
      this.grants.delete(grantId);
    }
    async revokeTabNow(tabId) {
      const ids = /* @__PURE__ */ new Set();
      for (const [grantId, grant] of this.grants) {
        if (grant.tabId === tabId) ids.add(grantId);
      }
      if (this.getSessionRules) {
        const rules = await this.getSessionRules({});
        for (const rule of rules) {
          if (rule.condition.tabIds?.includes(tabId)) ids.add(rule.id);
        }
      }
      if (ids.size === 0) return;
      const removeRuleIds = [...ids];
      await this.updateSessionRules({ addRules: [], removeRuleIds });
      for (const grantId of removeRuleIds) {
        const local = this.grants.get(grantId);
        if (local) this.clearTimer(local.timer);
        this.grants.delete(grantId);
      }
    }
    async sweepNow() {
      if (!this.getSessionRules) return;
      const rules = await this.getSessionRules({});
      for (const grant of this.grants.values()) this.clearTimer(grant.timer);
      this.grants.clear();
      if (rules.length === 0) return;
      await this.updateSessionRules({
        addRules: [],
        removeRuleIds: rules.map(({ id }) => id)
      });
    }
    uniqueRuleId() {
      let id = this.ruleId();
      while (this.grants.has(id)) id = this.ruleId();
      return id;
    }
    serialize(operation) {
      const result = this.operations.then(operation, operation);
      this.operations = result.then(() => void 0, () => void 0);
      return result;
    }
  };
  function randomToken() {
    const bytes = new Uint8Array(16);
    crypto.getRandomValues(bytes);
    return Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
  }
  function randomRuleId() {
    const value = new Uint32Array(1);
    crypto.getRandomValues(value);
    return 1e4 + value[0] % 2e9;
  }
  function escapeRegex(value) {
    return value.replace(/[.*+?^${}()|[\]\\]/gu, "\\$&");
  }

  // src/background/service-worker.ts
  function isExtensionMessage(message) {
    if (!message || typeof message !== "object" || !("type" in message)) return false;
    switch (message.type) {
      case "policy:get-current":
        return true;
      case "options:open":
        return true;
      case "policy:get-tab":
        return "tabId" in message && typeof message.tabId === "number";
      case "policy:set-tab":
        return "tabId" in message && typeof message.tabId === "number" && "mode" in message && isSiteMode(message.mode) && "expectedOrigin" in message && typeof message.expectedOrigin === "string";
      case "provider:authorize":
        return "source" in message && typeof message.source === "string" && "disableAutoplay" in message && typeof message.disableAutoplay === "boolean";
      case "provider:revoke":
        return "grantId" in message && typeof message.grantId === "number";
      default:
        return false;
    }
  }
  function originFor(tab) {
    if (!tab?.url) return void 0;
    try {
      const url = new URL(tab.url);
      return url.protocol === "http:" || url.protocol === "https:" ? url.origin : void 0;
    } catch {
      return void 0;
    }
  }
  async function contextFor(tab, store, blockedSubjectsStore) {
    const origin = originFor(tab);
    if (!origin) return { error: "unsupported-page" };
    return {
      origin,
      mode: await store.get(origin),
      blockedSubjects: await blockedSubjectsStore.get()
    };
  }
  async function handleExtensionMessage(message, sender, deps) {
    if (!isExtensionMessage(message)) return { error: "invalid-message" };
    const store = new SitePolicyStore(deps.storage);
    const blockedSubjectsStore = new BlockedSubjectsStore(deps.storage);
    switch (message.type) {
      case "options:open":
        await (deps.openOptionsPage ?? (() => chrome.runtime.openOptionsPage()))();
        return { opened: true };
      case "policy:get-current":
        return contextFor(sender.tab, store, blockedSubjectsStore);
      case "policy:get-tab":
        return contextFor(await deps.tabs.get(message.tabId), store, blockedSubjectsStore);
      case "policy:set-tab": {
        const origin = originFor(await deps.tabs.get(message.tabId));
        if (!origin) return { error: "unsupported-page" };
        if (origin !== message.expectedOrigin) return { error: "origin-changed" };
        await store.set(origin, message.mode);
        return { origin, mode: message.mode === "strict" ? "protected" : message.mode };
      }
      case "provider:authorize": {
        const tabId = sender.tab?.id;
        if (typeof tabId !== "number" || !originFor(sender.tab)) {
          return { error: "unsupported-page" };
        }
        if (!deps.providerGate) await productionProviderReady;
        return providerGate(deps).authorize(
          tabId,
          message.source,
          message.disableAutoplay
        );
      }
      case "provider:revoke": {
        const tabId = sender.tab?.id;
        if (typeof tabId !== "number" || !originFor(sender.tab)) {
          return { error: "unsupported-page" };
        }
        await providerGate(deps).revoke(tabId, message.grantId);
        return { origin: originFor(sender.tab), mode: "protected" };
      }
    }
  }
  var productionProviderGate = new ProviderRequestGate({
    updateSessionRules: (options) => chrome.declarativeNetRequest.updateSessionRules(options),
    getSessionRules: (filter) => chrome.declarativeNetRequest.getSessionRules(filter)
  });
  async function installProviderGateLifecycle(gate, tabs, navigation) {
    tabs.onRemoved.addListener((tabId) => void gate.revokeTab(tabId));
    navigation.onBeforeNavigate.addListener(({ tabId, frameId }) => {
      if (frameId === 0) void gate.revokeTab(tabId);
    });
    await gate.sweep();
  }
  function installFirstRun(runtime) {
    runtime.onInstalled.addListener(({ reason }) => {
      if (reason === "install") void runtime.openOptionsPage();
    });
  }
  var productionProviderReady = installProviderGateLifecycle(
    productionProviderGate,
    chrome.tabs,
    chrome.webNavigation
  );
  function providerGate(deps) {
    return deps.providerGate ?? productionProviderGate;
  }
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    void handleExtensionMessage(message, sender, {
      storage: chrome.storage.local,
      tabs: chrome.tabs,
      openOptionsPage: () => chrome.runtime.openOptionsPage()
    }).then(sendResponse);
    return true;
  });
  if (chrome.runtime.onInstalled) installFirstRun(chrome.runtime);
})();
//# sourceMappingURL=service-worker.js.map
