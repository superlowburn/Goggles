"use strict";
(() => {
  // src/shared/blocked-subjects.ts
  var blockedSubjectsKey = "blocked-subjects";
  var defaultTrumpKeywords = [
    "Donald Trump",
    "Donald J. Trump",
    "President Trump",
    "Former President Trump",
    "Trump",
    "@realDonaldTrump",
    "The Donald"
  ];
  function parseBlockedSubjects(value) {
    if (!value || typeof value !== "object") {
      return { enabled: false, keywords: [...defaultTrumpKeywords] };
    }
    const candidate = value;
    const keywords = Array.isArray(candidate.keywords) ? uniqueKeywords(candidate.keywords.filter((item) => typeof item === "string")) : [];
    return {
      enabled: candidate.enabled === true,
      keywords: keywords.length > 0 ? keywords : [...defaultTrumpKeywords]
    };
  }
  var BlockedSubjectsStore = class {
    constructor(area, onChanged) {
      this.area = area;
      this.onChanged = onChanged;
    }
    area;
    onChanged;
    async get() {
      return parseBlockedSubjects((await this.area.get(blockedSubjectsKey))[blockedSubjectsKey]);
    }
    async set(config) {
      await this.area.set({ [blockedSubjectsKey]: parseBlockedSubjects(config) });
    }
    watch(listener) {
      const onChange = (changes, area) => {
        if (area === "local" && blockedSubjectsKey in changes) {
          listener(parseBlockedSubjects(changes[blockedSubjectsKey]?.newValue));
        }
      };
      this.onChanged?.addListener(onChange);
      return () => this.onChanged?.removeListener(onChange);
    }
  };
  function uniqueKeywords(keywords) {
    const seen = /* @__PURE__ */ new Set();
    return keywords.flatMap((keyword) => {
      const normalized = keyword.replace(/\s+/gu, " ").trim();
      const key = normalized.toLocaleLowerCase();
      if (!normalized || seen.has(key)) return [];
      seen.add(key);
      return [normalized];
    });
  }

  // src/shared/site-policy.ts
  var socialPlatforms = [
    { id: "facebook", hosts: ["facebook.com"] },
    { id: "instagram", hosts: ["instagram.com"] },
    { id: "reddit", hosts: ["reddit.com"] },
    { id: "x", hosts: ["x.com", "twitter.com"] },
    { id: "tiktok", hosts: ["tiktok.com"] },
    { id: "threads", hosts: ["threads.com", "threads.net"] },
    { id: "bluesky", hosts: ["bsky.app"] },
    { id: "youtube", hosts: ["youtube.com"] }
  ];
  function normalizeOrigin(value) {
    try {
      const url = new URL(value);
      return url.protocol === "http:" || url.protocol === "https:" ? url.origin : null;
    } catch {
      return null;
    }
  }
  function socialPlatformForOrigin(origin) {
    const normalizedOrigin = normalizeOrigin(origin);
    if (!normalizedOrigin) return null;
    const hostname = new URL(normalizedOrigin).hostname;
    return socialPlatforms.find(
      ({ hosts }) => hosts.some((host) => hostname === host || hostname.endsWith(`.${host}`))
    ) ?? null;
  }

  // src/options/options.ts
  var SAVE_ERROR = "Couldn't save. Try again.";
  var socialLabels = {
    facebook: "Facebook",
    instagram: "Instagram",
    reddit: "Reddit",
    x: "X/Twitter",
    tiktok: "TikTok",
    threads: "Threads",
    bluesky: "Bluesky",
    youtube: "YouTube"
  };
  async function mountOptions(root, chromeApi) {
    const socialResponse = await chromeApi.runtime.sendMessage({ type: "policy:get-social" });
    if (!isSocialPoliciesResponse(socialResponse)) {
      throw new TypeError("Invalid social policy response");
    }
    const values = await chromeApi.storage.local.get(null);
    const blockedStore = new BlockedSubjectsStore(chromeApi.storage.local);
    const blocked = parseBlockedSubjects(values["blocked-subjects"]);
    const blockedEnabled = root.querySelector("#blocked-subjects-enabled");
    const blockedKeywords = root.querySelector("#blocked-subject-keywords");
    const blockedStatus = root.querySelector("#blocked-subjects-status");
    if (blockedEnabled) blockedEnabled.checked = blocked.enabled;
    if (blockedKeywords) blockedKeywords.value = blocked.keywords.join("\n");
    const saveBlockedSubjects = () => {
      const config = parseBlockedSubjects({
        enabled: blockedEnabled?.checked ?? false,
        keywords: uniqueKeywords(blockedKeywords?.value.split("\n") ?? [])
      });
      if (blockedKeywords) blockedKeywords.value = config.keywords.join("\n");
      void blockedStore.set(config).then(() => {
        values["blocked-subjects"] = config;
        if (blockedStatus) blockedStatus.textContent = "Saved locally";
      });
    };
    blockedEnabled?.addEventListener("change", saveBlockedSubjects);
    blockedKeywords?.addEventListener("change", saveBlockedSubjects);
    const platforms = root.querySelector("#social-platforms");
    const platformStatus = root.querySelector("#social-platforms-status");
    platforms?.replaceChildren(...socialPlatforms.map(({ id }) => {
      const toggle = document.createElement("input");
      toggle.type = "checkbox";
      toggle.setAttribute("role", "switch");
      toggle.dataset.socialPlatform = id;
      toggle.checked = socialResponse.socialPolicies[id] !== "trusted";
      const state = document.createElement("span");
      state.className = "platform-state";
      const updateState = () => {
        state.textContent = toggle.checked ? "On" : "Off";
      };
      updateState();
      const label = document.createElement("label");
      label.className = "platform-rule";
      const name = document.createElement("strong");
      name.textContent = socialLabels[id];
      label.append(name, state, toggle);
      toggle.addEventListener("change", () => {
        const prior = !toggle.checked;
        const mode = toggle.checked ? "protected" : "trusted";
        updateState();
        if (platformStatus) platformStatus.textContent = "";
        void chromeApi.runtime.sendMessage({
          type: "policy:set-social",
          platform: id,
          mode
        }).then((response) => {
          if (!isSocialWriteResponse(response, id, mode)) {
            throw new TypeError("Invalid social policy response");
          }
        }).catch(() => {
          toggle.checked = prior;
          updateState();
          if (platformStatus) platformStatus.textContent = SAVE_ERROR;
        });
      });
      return label;
    }));
    const rules = root.querySelector("#site-rules");
    const rulesStatus = root.querySelector("#site-rules-status");
    const renderRules = () => {
      if (!rules) return;
      const entries = Object.entries(values).filter(([key, value]) => {
        if (!key.startsWith("site-policy:") || value !== "protected" && value !== "strict") {
          return false;
        }
        const origin = key.slice("site-policy:".length);
        return normalizeOrigin(origin) === origin && !socialPlatformForOrigin(origin);
      }).sort(([first], [second]) => first.localeCompare(second));
      if (entries.length === 0) {
        const empty = document.createElement("p");
        empty.className = "empty-rules";
        empty.textContent = "No sites are always frosted.";
        rules.replaceChildren(empty);
        return;
      }
      rules.replaceChildren(...entries.map(([key]) => {
        const origin = key.slice("site-policy:".length);
        const row = document.createElement("div");
        row.className = "site-rule";
        row.dataset.siteOrigin = origin;
        const copy = document.createElement("span");
        const host = document.createElement("strong");
        host.textContent = origin;
        const label = document.createElement("span");
        label.textContent = "Always frost images and videos";
        copy.append(host, label);
        const remove = document.createElement("button");
        remove.type = "button";
        remove.dataset.removePolicy = key;
        remove.textContent = "Remove";
        remove.addEventListener("click", () => {
          const prior = values[key];
          delete values[key];
          renderRules();
          if (rulesStatus) rulesStatus.textContent = "";
          void chromeApi.storage.local.remove(key).catch(() => {
            values[key] = prior;
            renderRules();
            if (rulesStatus) rulesStatus.textContent = SAVE_ERROR;
          });
        });
        row.append(copy, remove);
        return row;
      }));
    };
    renderRules();
    const demo = root.querySelector("#demo-media");
    const demoReveal = root.querySelector("#demo-reveal");
    demoReveal?.addEventListener("click", () => {
      const revealed = demo?.classList.toggle("is-revealed") ?? false;
      demoReveal.textContent = revealed ? "Frost again" : "Click to reveal";
    });
  }
  function isSocialPoliciesResponse(value) {
    if (!value || typeof value !== "object" || !("socialPolicies" in value)) return false;
    const policies = value.socialPolicies;
    return Boolean(policies) && typeof policies === "object" && socialPlatforms.every(({ id }) => {
      const mode = policies[id];
      return mode === "protected" || mode === "trusted";
    });
  }
  function isSocialWriteResponse(value, platform, mode) {
    return value !== null && typeof value === "object" && "platform" in value && value.platform === platform && "mode" in value && value.mode === mode;
  }
  if (typeof chrome !== "undefined" && typeof document !== "undefined") {
    const root = document.querySelector("#app");
    if (root) void mountOptions(root, {
      runtime: { sendMessage: (message) => chrome.runtime.sendMessage(message) },
      storage: chrome.storage
    });
  }
})();
//# sourceMappingURL=options.js.map
