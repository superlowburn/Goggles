"use strict";
(() => {
  // src/shared/site-policy.ts
  function isSiteMode(value) {
    return value === "trusted" || value === "protected" || value === "strict";
  }

  // src/popup/popup.ts
  var TITLE = "Goggles";
  var SAVE_ERROR = "Could not update protection. Try again.";
  var START_ERROR = "Protection settings are unavailable on this page.";
  function isPolicyContext(value) {
    return typeof value === "object" && value !== null && "origin" in value && typeof value.origin === "string" && "mode" in value && isSiteMode(value.mode);
  }
  function isBlockedSubjectsConfig(value) {
    return typeof value === "object" && value !== null && "enabled" in value && typeof value.enabled === "boolean" && "keywords" in value && Array.isArray(value.keywords) && value.keywords.every((keyword) => typeof keyword === "string");
  }
  function createTextElement(tagName, className, text) {
    const element = document.createElement(tagName);
    element.className = className;
    element.textContent = text;
    return element;
  }
  async function mountPopup(root, chromeApi) {
    root.replaceChildren();
    document.title = TITLE;
    const heading = createTextElement("h1", "popup-title", TITLE);
    const site = createTextElement("p", "popup-site", "");
    const protectionSwitch = createTextElement("button", "popup-switch", "");
    protectionSwitch.type = "button";
    protectionSwitch.setAttribute("role", "switch");
    const switchCopy = createTextElement("span", "popup-switch-copy", "");
    const switchTitle = createTextElement("span", "popup-switch-title", "Frost images and videos");
    const switchDescription = createTextElement(
      "span",
      "popup-switch-description",
      ""
    );
    const switchControl = createTextElement("span", "popup-switch-control", "");
    switchControl.setAttribute("aria-hidden", "true");
    switchCopy.append(switchTitle, switchDescription);
    protectionSwitch.append(switchCopy, switchControl);
    const blockedSubjects = createTextElement("div", "popup-subjects", "");
    const subjectsTitle = createTextElement("span", "popup-subjects-title", "Blocked subjects");
    const subjectsState = createTextElement("span", "popup-subjects-state", "");
    const subjectsDescription = createTextElement("span", "popup-subjects-description", "");
    blockedSubjects.append(subjectsTitle, subjectsState, subjectsDescription);
    const error = createTextElement("p", "popup-error", "");
    error.setAttribute("role", "alert");
    error.hidden = true;
    const settings = createTextElement("button", "popup-settings", "Open settings");
    settings.type = "button";
    settings.addEventListener("click", () => void chromeApi.runtime.openOptionsPage());
    root.append(heading, site, protectionSwitch, error, blockedSubjects, settings);
    const [activeTab] = await chromeApi.tabs.query({ active: true, currentWindow: true });
    if (typeof activeTab?.id !== "number") {
      error.textContent = START_ERROR;
      error.hidden = false;
      return;
    }
    const tabId = activeTab.id;
    const initialResponse = await chromeApi.runtime.sendMessage({
      type: "policy:get-tab",
      tabId
    });
    if (!isPolicyContext(initialResponse)) {
      error.textContent = START_ERROR;
      error.hidden = false;
      return;
    }
    if (!isBlockedSubjectsConfig(initialResponse.blockedSubjects)) {
      error.textContent = START_ERROR;
      error.hidden = false;
      return;
    }
    subjectsState.textContent = initialResponse.blockedSubjects.enabled ? "On" : "Off";
    subjectsDescription.textContent = initialResponse.blockedSubjects.enabled ? "Stay frosted on every site." : "Turn on matching in Settings.";
    let hostname;
    try {
      hostname = new URL(initialResponse.origin).hostname;
    } catch {
      error.textContent = START_ERROR;
      error.hidden = false;
      return;
    }
    site.textContent = hostname;
    let confirmedMode = initialResponse.mode === "trusted" ? "trusted" : "protected";
    const selectMode = (selectedMode) => {
      const protectedMode = selectedMode === "protected";
      protectionSwitch.setAttribute("aria-checked", String(protectedMode));
      switchDescription.textContent = protectedMode ? "On \u2014 click an item to reveal it." : "Off \u2014 ordinary media shows normally.";
    };
    const setBusy = (busy) => {
      protectionSwitch.disabled = busy;
    };
    selectMode(confirmedMode);
    protectionSwitch.addEventListener("click", async () => {
      if (protectionSwitch.disabled) return;
      const priorMode = confirmedMode;
      const nextMode = confirmedMode === "protected" ? "trusted" : "protected";
      error.hidden = true;
      error.textContent = "";
      selectMode(nextMode);
      setBusy(true);
      try {
        const response = await chromeApi.runtime.sendMessage({
          type: "policy:set-tab",
          tabId,
          mode: nextMode,
          expectedOrigin: initialResponse.origin
        });
        if (!isPolicyContext(response) || response.mode !== nextMode || response.origin !== initialResponse.origin) {
          throw new TypeError("Invalid policy response");
        }
        confirmedMode = nextMode;
        selectMode(confirmedMode);
      } catch {
        selectMode(priorMode);
        error.textContent = SAVE_ERROR;
        error.hidden = false;
      } finally {
        setBusy(false);
      }
    });
  }
  var popupRoot = document.querySelector("#app");
  if (popupRoot && typeof chrome !== "undefined") {
    void mountPopup(popupRoot, {
      tabs: { query: (queryInfo) => chrome.tabs.query(queryInfo) },
      runtime: {
        sendMessage: (message) => chrome.runtime.sendMessage(message),
        openOptionsPage: () => chrome.runtime.openOptionsPage()
      }
    }).catch(() => {
      popupRoot.replaceChildren(createTextElement("p", "popup-error", START_ERROR));
    });
  }
})();
//# sourceMappingURL=popup.js.map
