"use strict";
(() => {
  // src/content/shadow-bridge.ts
  var eventName = "eclipse-goggles-open-shadow";
  var originalAttachShadow = Element.prototype.attachShadow;
  function attachShadow(init) {
    const root = originalAttachShadow.call(this, init);
    if (init.mode === "open") {
      this.dispatchEvent(new CustomEvent(eventName, { bubbles: true }));
    }
    return root;
  }
  Object.defineProperties(attachShadow, {
    name: { value: originalAttachShadow.name },
    length: { value: originalAttachShadow.length }
  });
  Element.prototype.attachShadow = attachShadow;
})();
//# sourceMappingURL=shadow-bridge.js.map
