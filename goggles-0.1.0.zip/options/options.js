"use strict";
(() => {
  // src/shared/blocked-subjects.ts
  var blockedSubjectsKey = "blocked-subjects";
  var defaultTrumpKeywords = [
    "Donald Trump",
    "Donald J. Trump",
    "President Trump",
    "Former President Trump",
    "Trump",
    "@realDonaldTrump",
    "The Donald"
  ];
  function parseBlockedSubjects(value) {
    if (!value || typeof value !== "object") {
      return { enabled: false, keywords: [...defaultTrumpKeywords] };
    }
    const candidate = value;
    const keywords = Array.isArray(candidate.keywords) ? uniqueKeywords(candidate.keywords.filter((item) => typeof item === "string")) : [];
    return {
      enabled: candidate.enabled === true,
      keywords: keywords.length > 0 ? keywords : [...defaultTrumpKeywords]
    };
  }
  var BlockedSubjectsStore = class {
    constructor(area, onChanged) {
      this.area = area;
      this.onChanged = onChanged;
    }
    area;
    onChanged;
    async get() {
      return parseBlockedSubjects((await this.area.get(blockedSubjectsKey))[blockedSubjectsKey]);
    }
    async set(config) {
      await this.area.set({ [blockedSubjectsKey]: parseBlockedSubjects(config) });
    }
    watch(listener) {
      const onChange = (changes, area) => {
        if (area === "local" && blockedSubjectsKey in changes) {
          listener(parseBlockedSubjects(changes[blockedSubjectsKey]?.newValue));
        }
      };
      this.onChanged?.addListener(onChange);
      return () => this.onChanged?.removeListener(onChange);
    }
  };
  function uniqueKeywords(keywords) {
    const seen = /* @__PURE__ */ new Set();
    return keywords.flatMap((keyword) => {
      const normalized = keyword.replace(/\s+/gu, " ").trim();
      const key = normalized.toLocaleLowerCase();
      if (!normalized || seen.has(key)) return [];
      seen.add(key);
      return [normalized];
    });
  }

  // src/options/options.ts
  async function mountOptions(root, chromeApi) {
    const values = await chromeApi.storage.local.get(null);
    const blockedStore = new BlockedSubjectsStore(chromeApi.storage.local);
    const blocked = parseBlockedSubjects(values["blocked-subjects"]);
    const blockedEnabled = root.querySelector("#blocked-subjects-enabled");
    const blockedKeywords = root.querySelector("#blocked-subject-keywords");
    const blockedStatus = root.querySelector("#blocked-subjects-status");
    if (blockedEnabled) blockedEnabled.checked = blocked.enabled;
    if (blockedKeywords) blockedKeywords.value = blocked.keywords.join("\n");
    const saveBlockedSubjects = () => {
      const config = parseBlockedSubjects({
        enabled: blockedEnabled?.checked ?? false,
        keywords: uniqueKeywords(blockedKeywords?.value.split("\n") ?? [])
      });
      if (blockedKeywords) blockedKeywords.value = config.keywords.join("\n");
      void blockedStore.set(config).then(() => {
        values["blocked-subjects"] = config;
        if (blockedStatus) blockedStatus.textContent = "Saved locally";
      });
    };
    blockedEnabled?.addEventListener("change", saveBlockedSubjects);
    blockedKeywords?.addEventListener("change", saveBlockedSubjects);
    const rules = root.querySelector("#site-rules");
    const renderRules = () => {
      if (!rules) return;
      const entries = Object.entries(values).filter(([key, value]) => key.startsWith("site-policy:") && value === "trusted");
      if (entries.length === 0) {
        const empty = document.createElement("p");
        empty.className = "empty-rules";
        empty.textContent = "No sites are showing images and videos. Use the Goggles menu on a page to change this.";
        rules.replaceChildren(empty);
        return;
      }
      rules.replaceChildren(...entries.map(([key]) => {
        const origin = key.slice("site-policy:".length);
        const row = document.createElement("div");
        row.className = "site-rule";
        const copy = document.createElement("span");
        const host = document.createElement("strong");
        try {
          host.textContent = new URL(origin).hostname;
        } catch {
          host.textContent = origin;
        }
        const label = document.createElement("span");
        label.textContent = "Showing images and videos";
        copy.append(host, label);
        const remove = document.createElement("button");
        remove.type = "button";
        remove.dataset.removePolicy = key;
        remove.textContent = "Frost images and videos again";
        remove.addEventListener("click", () => {
          delete values[key];
          renderRules();
          void chromeApi.storage.local.remove(key);
        });
        row.append(copy, remove);
        return row;
      }));
    };
    renderRules();
    const demo = root.querySelector("#demo-media");
    const demoReveal = root.querySelector("#demo-reveal");
    demoReveal?.addEventListener("click", () => {
      const revealed = demo?.classList.toggle("is-revealed") ?? false;
      demoReveal.textContent = revealed ? "Frost again" : "Click to reveal";
    });
  }
  if (typeof chrome !== "undefined" && typeof document !== "undefined") {
    const root = document.querySelector("#app");
    if (root) void mountOptions(root, chrome);
  }
})();
//# sourceMappingURL=options.js.map
