"use strict";
(() => {
  // src/shared/blocked-subjects.ts
  var blockedSubjectsKey = "blocked-subjects";
  var defaultTrumpKeywords = [
    "Donald Trump",
    "Donald J. Trump",
    "President Trump",
    "Former President Trump",
    "Trump",
    "@realDonaldTrump",
    "The Donald"
  ];
  function parseBlockedSubjects(value) {
    if (!value || typeof value !== "object") {
      return { subjects: defaultSubjects() };
    }
    const candidate = value;
    if (Array.isArray(candidate.subjects)) {
      const subjects = candidate.subjects.flatMap((subject) => {
        if (!subject || typeof subject !== "object") return [];
        const item = subject;
        const name = typeof item.name === "string" ? normalizeName(item.name) : "";
        const keywords2 = Array.isArray(item.keywords) ? uniqueKeywords(item.keywords.filter((keyword) => typeof keyword === "string")) : [];
        return name && keywords2.length > 0 ? [{ name, enabled: item.enabled === true, keywords: keywords2 }] : [];
      });
      return { subjects };
    }
    const keywords = Array.isArray(candidate.keywords) ? uniqueKeywords(candidate.keywords.filter((item) => typeof item === "string")) : [];
    return {
      subjects: [{
        name: "Donald Trump",
        enabled: candidate.enabled === true,
        keywords: keywords.length > 0 ? keywords : [...defaultTrumpKeywords]
      }]
    };
  }
  function suggestSubjectKeywords(name) {
    const normalized = normalizeName(name);
    if (!normalized) return [];
    const parts = normalized.split(" ");
    return uniqueKeywords([normalized, ...parts.length > 1 ? [parts.at(-1)] : []]);
  }
  var BlockedSubjectsStore = class {
    constructor(area, onChanged) {
      this.area = area;
      this.onChanged = onChanged;
    }
    area;
    onChanged;
    async get() {
      return parseBlockedSubjects((await this.area.get(blockedSubjectsKey))[blockedSubjectsKey]);
    }
    async set(config) {
      await this.area.set({ [blockedSubjectsKey]: parseBlockedSubjects(config) });
    }
    watch(listener) {
      const onChange = (changes, area) => {
        if (area === "local" && blockedSubjectsKey in changes) {
          listener(parseBlockedSubjects(changes[blockedSubjectsKey]?.newValue));
        }
      };
      this.onChanged?.addListener(onChange);
      return () => this.onChanged?.removeListener(onChange);
    }
  };
  function uniqueKeywords(keywords) {
    const seen = /* @__PURE__ */ new Set();
    return keywords.flatMap((keyword) => {
      const normalized = keyword.replace(/\s+/gu, " ").trim();
      const key = normalized.toLocaleLowerCase();
      if (!normalized || seen.has(key)) return [];
      seen.add(key);
      return [normalized];
    });
  }
  function normalizeName(name) {
    return name.replace(/\s+/gu, " ").trim();
  }
  function defaultSubjects() {
    return [{ name: "Donald Trump", enabled: false, keywords: [...defaultTrumpKeywords] }];
  }

  // src/shared/site-policy.ts
  var socialPlatforms = [
    { id: "facebook", hosts: ["facebook.com"] },
    { id: "instagram", hosts: ["instagram.com"] },
    { id: "reddit", hosts: ["reddit.com"] },
    { id: "x", hosts: ["x.com", "twitter.com"] },
    { id: "tiktok", hosts: ["tiktok.com"] },
    { id: "threads", hosts: ["threads.com", "threads.net"] },
    { id: "bluesky", hosts: ["bsky.app"] },
    { id: "youtube", hosts: ["youtube.com"] }
  ];
  function normalizeOrigin(value) {
    try {
      const url = new URL(value);
      return url.protocol === "http:" || url.protocol === "https:" ? url.origin : null;
    } catch {
      return null;
    }
  }
  function socialPlatformForOrigin(origin) {
    const normalizedOrigin = normalizeOrigin(origin);
    if (!normalizedOrigin) return null;
    const hostname = new URL(normalizedOrigin).hostname;
    return socialPlatforms.find(
      ({ hosts }) => hosts.some((host) => hostname === host || hostname.endsWith(`.${host}`))
    ) ?? null;
  }

  // src/options/options.ts
  var SAVE_ERROR = "Couldn't save. Try again.";
  var socialLabels = {
    facebook: "Facebook",
    instagram: "Instagram",
    reddit: "Reddit",
    x: "X/Twitter",
    tiktok: "TikTok",
    threads: "Threads",
    bluesky: "Bluesky",
    youtube: "YouTube"
  };
  async function mountOptions(root, chromeApi) {
    const socialResponse = await chromeApi.runtime.sendMessage({ type: "policy:get-social" });
    if (!isSocialPoliciesResponse(socialResponse)) {
      throw new TypeError("Invalid social policy response");
    }
    const values = await chromeApi.storage.local.get(null);
    const blockedStore = new BlockedSubjectsStore(chromeApi.storage.local);
    let blocked = parseBlockedSubjects(values["blocked-subjects"]);
    const blockedStatus = root.querySelector("#blocked-subjects-status");
    const subjectList = root.querySelector("#subject-list");
    const saveBlockedSubjects = () => {
      void blockedStore.set(blocked).then(() => {
        values["blocked-subjects"] = blocked;
        if (blockedStatus) blockedStatus.textContent = "Saved locally";
      });
    };
    const renderSubjects = () => {
      if (!subjectList) return;
      subjectList.replaceChildren(...(blocked.subjects ?? []).map((subject, index) => {
        const card = document.createElement("div");
        card.className = "subject-card";
        const toggle = document.createElement("label");
        toggle.className = "subject-toggle";
        const toggleId = index === 0 ? "blocked-subjects-enabled" : `blocked-subject-${index}-enabled`;
        toggle.htmlFor = toggleId;
        const copy = document.createElement("span");
        const title = document.createElement("strong");
        title.textContent = subject.name;
        const hint = document.createElement("small");
        hint.textContent = "Frost likely matches";
        copy.append(title, hint);
        const enabled = document.createElement("input");
        enabled.id = toggleId;
        enabled.type = "checkbox";
        enabled.checked = subject.enabled;
        enabled.addEventListener("change", () => {
          subject.enabled = enabled.checked;
          saveBlockedSubjects();
        });
        toggle.append(copy, enabled);
        const details = document.createElement("details");
        details.className = "keyword-editor";
        const summary = document.createElement("summary");
        summary.textContent = "Matching words";
        const keywordLabel = document.createElement("label");
        const keywordId = index === 0 ? "blocked-subject-keywords" : `blocked-subject-${index}-keywords`;
        keywordLabel.htmlFor = keywordId;
        const keywordHint = document.createElement("span");
        keywordHint.textContent = "One phrase per line.";
        const keywords = document.createElement("textarea");
        keywords.id = keywordId;
        keywords.rows = 7;
        keywords.spellcheck = false;
        keywords.value = subject.keywords.join("\n");
        keywords.addEventListener("change", () => {
          subject.keywords = uniqueKeywords(keywords.value.split("\n"));
          keywords.value = subject.keywords.join("\n");
          saveBlockedSubjects();
        });
        keywordLabel.append(keywordHint, keywords);
        details.append(summary, keywordLabel);
        const remove = document.createElement("button");
        remove.type = "button";
        remove.className = "remove-subject";
        remove.textContent = "Remove subject";
        remove.addEventListener("click", () => {
          blocked.subjects?.splice(index, 1);
          blocked = parseBlockedSubjects(blocked);
          renderSubjects();
          saveBlockedSubjects();
        });
        card.append(toggle, details, remove);
        return card;
      }));
    };
    renderSubjects();
    const newSubjectName = root.querySelector("#new-subject-name");
    const suggestions = root.querySelector("#subject-suggestions");
    root.querySelector("#suggest-subject")?.addEventListener("click", () => {
      const keywords = suggestSubjectKeywords(newSubjectName?.value ?? "");
      if (!suggestions || keywords.length === 0) return;
      const heading = document.createElement("strong");
      heading.textContent = "Suggested matching words";
      const choices = keywords.map((keyword, index) => {
        const label = document.createElement("label");
        const input = document.createElement("input");
        input.type = "checkbox";
        input.checked = index === 0;
        input.value = keyword;
        label.append(input, document.createTextNode(keyword));
        return label;
      });
      const add = document.createElement("button");
      add.id = "add-subject";
      add.type = "button";
      add.textContent = "Add subject";
      add.addEventListener("click", () => {
        const selected = Array.from(suggestions.querySelectorAll("input:checked")).map((input) => input.value);
        if (selected.length === 0) return;
        blocked.subjects?.push({ name: keywords[0], enabled: true, keywords: selected });
        renderSubjects();
        saveBlockedSubjects();
        suggestions.hidden = true;
        suggestions.replaceChildren();
        if (newSubjectName) newSubjectName.value = "";
      });
      suggestions.replaceChildren(heading, ...choices, add);
      suggestions.hidden = false;
    });
    const platforms = root.querySelector("#social-platforms");
    const platformStatus = root.querySelector("#social-platforms-status");
    platforms?.replaceChildren(...socialPlatforms.map(({ id }) => {
      const toggle = document.createElement("input");
      toggle.type = "checkbox";
      toggle.setAttribute("role", "switch");
      toggle.dataset.socialPlatform = id;
      toggle.checked = socialResponse.socialPolicies[id] !== "trusted";
      const state = document.createElement("span");
      state.className = "platform-state";
      const updateState = () => {
        state.textContent = toggle.checked ? "On" : "Off";
      };
      updateState();
      const label = document.createElement("label");
      label.className = "platform-rule";
      const name = document.createElement("strong");
      name.textContent = socialLabels[id];
      label.append(name, state, toggle);
      toggle.addEventListener("change", () => {
        const prior = !toggle.checked;
        const mode = toggle.checked ? "protected" : "trusted";
        updateState();
        if (platformStatus) platformStatus.textContent = "";
        void chromeApi.runtime.sendMessage({
          type: "policy:set-social",
          platform: id,
          mode
        }).then((response) => {
          if (!isSocialWriteResponse(response, id, mode)) {
            throw new TypeError("Invalid social policy response");
          }
        }).catch(() => {
          toggle.checked = prior;
          updateState();
          if (platformStatus) platformStatus.textContent = SAVE_ERROR;
        });
      });
      return label;
    }));
    const rules = root.querySelector("#site-rules");
    const rulesStatus = root.querySelector("#site-rules-status");
    const renderRules = () => {
      if (!rules) return;
      const entries = Object.entries(values).filter(([key, value]) => {
        if (!key.startsWith("site-policy:") || value !== "protected" && value !== "strict") {
          return false;
        }
        const origin = key.slice("site-policy:".length);
        return normalizeOrigin(origin) === origin && !socialPlatformForOrigin(origin);
      }).sort(([first], [second]) => first.localeCompare(second));
      if (entries.length === 0) {
        const empty = document.createElement("p");
        empty.className = "empty-rules";
        empty.textContent = "No sites are always frosted.";
        rules.replaceChildren(empty);
        return;
      }
      rules.replaceChildren(...entries.map(([key]) => {
        const origin = key.slice("site-policy:".length);
        const row = document.createElement("div");
        row.className = "site-rule";
        row.dataset.siteOrigin = origin;
        const copy = document.createElement("span");
        const host = document.createElement("strong");
        host.textContent = origin;
        const label = document.createElement("span");
        label.textContent = "Always frost images and videos";
        copy.append(host, label);
        const remove = document.createElement("button");
        remove.type = "button";
        remove.dataset.removePolicy = key;
        remove.textContent = "Remove";
        remove.addEventListener("click", () => {
          const prior = values[key];
          delete values[key];
          renderRules();
          if (rulesStatus) rulesStatus.textContent = "";
          void chromeApi.storage.local.remove(key).catch(() => {
            values[key] = prior;
            renderRules();
            if (rulesStatus) rulesStatus.textContent = SAVE_ERROR;
          });
        });
        row.append(copy, remove);
        return row;
      }));
    };
    renderRules();
    const demo = root.querySelector("#demo-media");
    const demoReveal = root.querySelector("#demo-reveal");
    demoReveal?.addEventListener("click", () => {
      const revealed = demo?.classList.toggle("is-revealed") ?? false;
      demoReveal.textContent = revealed ? "Frost again" : "Click to reveal";
    });
  }
  function isSocialPoliciesResponse(value) {
    if (!value || typeof value !== "object" || !("socialPolicies" in value)) return false;
    const policies = value.socialPolicies;
    return Boolean(policies) && typeof policies === "object" && socialPlatforms.every(({ id }) => {
      const mode = policies[id];
      return mode === "protected" || mode === "trusted";
    });
  }
  function isSocialWriteResponse(value, platform, mode) {
    return value !== null && typeof value === "object" && "platform" in value && value.platform === platform && "mode" in value && value.mode === mode;
  }
  if (typeof chrome !== "undefined" && typeof document !== "undefined") {
    const root = document.querySelector("#app");
    if (root) void mountOptions(root, {
      runtime: { sendMessage: (message) => chrome.runtime.sendMessage(message) },
      storage: chrome.storage
    });
  }
})();
//# sourceMappingURL=options.js.map
