"use strict";
(() => {
  // src/shared/site-policy.ts
  var socialMigrationPromises = /* @__PURE__ */ new WeakMap();
  var protectedMode = "protected";
  var trustedMode = "trusted";
  var defaultPolicyKey = "default-site-mode";
  var socialPlatforms = [
    { id: "facebook", hosts: ["facebook.com"] },
    { id: "instagram", hosts: ["instagram.com"] },
    { id: "reddit", hosts: ["reddit.com"] },
    { id: "x", hosts: ["x.com", "twitter.com"] },
    { id: "tiktok", hosts: ["tiktok.com"] },
    { id: "threads", hosts: ["threads.com", "threads.net"] },
    { id: "bluesky", hosts: ["bsky.app"] },
    { id: "youtube", hosts: ["youtube.com"] }
  ];
  function policyKey(origin) {
    return `site-policy:${origin}`;
  }
  function socialPolicyKey(platform) {
    return `social-policy:${platform}`;
  }
  function descriptionsKey(origin) {
    return `site-descriptions:${origin}`;
  }
  function isSiteMode(value) {
    return value === "trusted" || value === "protected" || value === "strict";
  }
  function normalizeOrigin(value) {
    try {
      const url = new URL(value);
      return url.protocol === "http:" || url.protocol === "https:" ? url.origin : null;
    } catch {
      return null;
    }
  }
  function socialPlatformForOrigin(origin) {
    const normalizedOrigin = normalizeOrigin(origin);
    if (!normalizedOrigin) return null;
    const hostname = new URL(normalizedOrigin).hostname;
    return socialPlatforms.find(
      ({ hosts }) => hosts.some((host) => hostname === host || hostname.endsWith(`.${host}`))
    ) ?? null;
  }
  function defaultPolicyForOrigin(origin) {
    const normalizedOrigin = normalizeOrigin(origin);
    if (!normalizedOrigin) return protectedMode;
    return socialPlatformForOrigin(normalizedOrigin) ? protectedMode : trustedMode;
  }
  function supportedMode(value) {
    if (value === "strict") return "protected";
    return value === "trusted" || value === "protected" ? value : null;
  }
  var SitePolicyStore = class {
    constructor(area, onChanged) {
      this.area = area;
      this.onChanged = onChanged;
    }
    area;
    onChanged;
    async get(origin) {
      const normalizedOrigin = normalizeOrigin(origin);
      if (!normalizedOrigin) return defaultPolicyForOrigin(origin);
      const exactKey = policyKey(normalizedOrigin);
      const platform = socialPlatformForOrigin(normalizedOrigin);
      if (!platform) {
        return supportedMode((await this.area.get(exactKey))[exactKey]) ?? trustedMode;
      }
      const platformKey = socialPolicyKey(platform.id);
      const values = await this.area.get([platformKey, exactKey]);
      if (platformKey in values) return supportedMode(values[platformKey]) ?? protectedMode;
      return supportedMode(values[exactKey]) ?? defaultPolicyForOrigin(normalizedOrigin);
    }
    async set(origin, mode) {
      const normalizedOrigin = normalizeOrigin(origin);
      if (!normalizedOrigin) return;
      const platform = socialPlatformForOrigin(normalizedOrigin);
      const key = platform ? socialPolicyKey(platform.id) : policyKey(normalizedOrigin);
      await this.area.set({ [key]: supportedMode(mode) ?? protectedMode });
    }
    async setDefault(mode) {
      await this.area.set({ [defaultPolicyKey]: supportedMode(mode) ?? protectedMode });
    }
    async getDescriptionsVisible(origin) {
      const key = descriptionsKey(origin);
      return (await this.area.get(key))[key] === true;
    }
    async setDescriptionsVisible(origin, visible) {
      await this.area.set({ [descriptionsKey(origin)]: visible });
    }
    watch(origin, listener) {
      const normalizedOrigin = normalizeOrigin(origin);
      if (!normalizedOrigin) return () => {
      };
      const exactKey = policyKey(normalizedOrigin);
      const platform = socialPlatformForOrigin(normalizedOrigin);
      const keys = platform ? [socialPolicyKey(platform.id), exactKey] : [exactKey];
      const onChange = (changes, areaName) => {
        if (areaName !== "local" || !keys.some((key) => key in changes)) return;
        void this.get(normalizedOrigin).then(listener);
      };
      this.onChanged?.addListener(onChange);
      return () => this.onChanged?.removeListener(onChange);
    }
  };
  async function migrateSocialPolicies(area) {
    const values = await area.get(null) ?? {};
    const updates = {};
    for (const platform of socialPlatforms) {
      const platformKey = socialPolicyKey(platform.id);
      if (platformKey in values) continue;
      const hasTrustedLegacyRule = Object.entries(values).some(([key, value]) => {
        if (!key.startsWith("site-policy:") || supportedMode(value) !== trustedMode) return false;
        const origin = key.slice("site-policy:".length);
        return normalizeOrigin(origin) === origin && socialPlatformForOrigin(origin)?.id === platform.id;
      });
      if (hasTrustedLegacyRule) updates[platformKey] = trustedMode;
    }
    if (Object.keys(updates).length > 0) await area.set(updates);
  }
  function prepareSocialPolicies(area) {
    let migration = socialMigrationPromises.get(area);
    if (!migration) {
      migration = migrateSocialPolicies(area).catch(() => {
        socialMigrationPromises.delete(area);
      });
      socialMigrationPromises.set(area, migration);
    }
    return migration;
  }

  // src/shared/blocked-subjects.ts
  var blockedSubjectsKey = "blocked-subjects";
  var defaultTrumpKeywords = [
    "Donald Trump",
    "Donald J. Trump",
    "President Trump",
    "Former President Trump",
    "Trump",
    "@realDonaldTrump",
    "The Donald"
  ];
  function parseBlockedSubjects(value) {
    if (!value || typeof value !== "object") {
      return { enabled: false, keywords: [...defaultTrumpKeywords] };
    }
    const candidate = value;
    const keywords = Array.isArray(candidate.keywords) ? uniqueKeywords(candidate.keywords.filter((item) => typeof item === "string")) : [];
    return {
      enabled: candidate.enabled === true,
      keywords: keywords.length > 0 ? keywords : [...defaultTrumpKeywords]
    };
  }
  var BlockedSubjectsStore = class {
    constructor(area, onChanged) {
      this.area = area;
      this.onChanged = onChanged;
    }
    area;
    onChanged;
    async get() {
      return parseBlockedSubjects((await this.area.get(blockedSubjectsKey))[blockedSubjectsKey]);
    }
    async set(config) {
      await this.area.set({ [blockedSubjectsKey]: parseBlockedSubjects(config) });
    }
    watch(listener) {
      const onChange = (changes, area) => {
        if (area === "local" && blockedSubjectsKey in changes) {
          listener(parseBlockedSubjects(changes[blockedSubjectsKey]?.newValue));
        }
      };
      this.onChanged?.addListener(onChange);
      return () => this.onChanged?.removeListener(onChange);
    }
  };
  function uniqueKeywords(keywords) {
    const seen = /* @__PURE__ */ new Set();
    return keywords.flatMap((keyword) => {
      const normalized = keyword.replace(/\s+/gu, " ").trim();
      const key = normalized.toLocaleLowerCase();
      if (!normalized || seen.has(key)) return [];
      seen.add(key);
      return [normalized];
    });
  }

  // src/background/service-worker.ts
  function isSocialPlatformId(value) {
    return typeof value === "string" && socialPlatforms.some(({ id }) => id === value);
  }
  function isOptionsSender(sender, extensionId) {
    if (sender.id !== extensionId || !sender.url) return false;
    try {
      const url = new URL(sender.url);
      return url.protocol === "chrome-extension:" && url.hostname === extensionId && (url.pathname === "/options/options.html" || url.pathname === "/dist/options/options.html");
    } catch {
      return false;
    }
  }
  function isExtensionMessage(message) {
    if (!message || typeof message !== "object" || !("type" in message)) return false;
    switch (message.type) {
      case "policy:get-current":
      case "policy:get-social":
        return true;
      case "options:open":
        return true;
      case "policy:get-tab":
        return "tabId" in message && typeof message.tabId === "number";
      case "policy:set-tab":
        return "tabId" in message && typeof message.tabId === "number" && "mode" in message && isSiteMode(message.mode) && "expectedOrigin" in message && typeof message.expectedOrigin === "string";
      case "policy:set-social":
        return "platform" in message && isSocialPlatformId(message.platform) && "mode" in message && (message.mode === "protected" || message.mode === "trusted");
      default:
        return false;
    }
  }
  function originFor(tab) {
    return tab?.url ? normalizeOrigin(tab.url) ?? void 0 : void 0;
  }
  async function contextFor(tab, store, blockedSubjectsStore) {
    const origin = originFor(tab);
    if (!origin) return { error: "unsupported-page" };
    return {
      origin,
      mode: await store.get(origin),
      blockedSubjects: await blockedSubjectsStore.get()
    };
  }
  async function handleExtensionMessage(message, sender, deps) {
    if (!isExtensionMessage(message)) return { error: "invalid-message" };
    if ((message.type === "policy:get-social" || message.type === "policy:set-social") && !isOptionsSender(sender, deps.extensionId ?? chrome.runtime.id)) {
      return { error: "invalid-message" };
    }
    await (deps.policyReady ?? prepareSocialPolicies(deps.storage));
    const store = new SitePolicyStore(deps.storage);
    const blockedSubjectsStore = new BlockedSubjectsStore(deps.storage);
    switch (message.type) {
      case "options:open":
        await (deps.openOptionsPage ?? (() => chrome.runtime.openOptionsPage()))();
        return { opened: true };
      case "policy:get-current":
        return contextFor(sender.tab, store, blockedSubjectsStore);
      case "policy:get-social": {
        const keys = socialPlatforms.map(({ id }) => socialPolicyKey(id));
        const values = await deps.storage.get(keys);
        return {
          socialPolicies: Object.fromEntries(socialPlatforms.map(({ id }) => [
            id,
            values[socialPolicyKey(id)] === "trusted" ? "trusted" : "protected"
          ]))
        };
      }
      case "policy:set-social":
        await deps.storage.set({ [socialPolicyKey(message.platform)]: message.mode });
        return { platform: message.platform, mode: message.mode };
      case "policy:get-tab":
        return contextFor(await deps.tabs.get(message.tabId), store, blockedSubjectsStore);
      case "policy:set-tab": {
        const origin = originFor(await deps.tabs.get(message.tabId));
        if (!origin) return { error: "unsupported-page" };
        if (origin !== message.expectedOrigin) return { error: "origin-changed" };
        await store.set(origin, message.mode);
        return { origin, mode: message.mode === "strict" ? "protected" : message.mode };
      }
    }
  }
  function installFirstRun(runtime, storage) {
    runtime.onInstalled.addListener(({ reason }) => {
      if (storage) void prepareSocialPolicies(storage);
      if (reason === "install") void runtime.openOptionsPage();
    });
  }
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    void handleExtensionMessage(message, sender, {
      storage: chrome.storage.local,
      tabs: chrome.tabs,
      openOptionsPage: () => chrome.runtime.openOptionsPage(),
      policyReady: productionPolicyReady,
      extensionId: chrome.runtime.id
    }).then(sendResponse);
    return true;
  });
  var productionPolicyReady = prepareSocialPolicies(chrome.storage.local);
  if (chrome.runtime.onInstalled) installFirstRun(chrome.runtime, chrome.storage.local);
})();
//# sourceMappingURL=service-worker.js.map
